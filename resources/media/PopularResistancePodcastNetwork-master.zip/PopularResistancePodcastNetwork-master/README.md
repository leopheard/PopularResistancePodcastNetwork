Popular Resistance Podcast Network<br>
=============================

<a href="www.kodi.tv">KODI</a> / XBMC / Firestick audio addon for the <a href="https://popularresistance.org/prpn/">Popular Resistance Podcast Network</a> podcasts.<br>

Clearing The Fog<br>
Voices With Vision<br>
Common Censored<br>
Black Agenda Radio<br>
Moderate Rebels<br>
Act Out<br>
Drug Positive<br>

To install this addon, either use the <a href="https://www.tvaddons.co/github-browser-kodi/">Kodi Github installer</a> addon or save the .zip file downloaded from the 'clone or download' button to somewhere the Kodi can access. Then on the Kodi, go to addons > install from zip file.<br>

#PRPN
#PopularResistance

<a href="https://popularresistance.org/prpn/">Popular Resistance Podcast Network</a><br>
<a href="https://popularresistance.org/prpn/"><img src="https://popularresistance-uploads.s3.amazonaws.com/uploads/2018/09/prpn-banner.jpg">
